﻿using System;

namespace Employee.Exceptions
{
    public class EmployeeException:ApplicationException
    {
        public EmployeeException(string name) : base(name)
        {

        }
    }
}
