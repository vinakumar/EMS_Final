﻿using System;
using Employee.Entity;
using Employee.Exceptions;
using Employee.DataAccess;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Linq;
namespace Employee.BusinessLogic
{
    public class EmployeeLogic
    {
        /*****************Validating data of employee******************************/
        public static bool CheckEmployee(EmployeeEntity employee)
        {
            var emailCheck = new Regex(@"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com\b");
            var dateCheck = new Regex(@"(0[1-9]|[12][0-9]|3[01])[- \.\/\-](0[1-9]|1[012])[- \.\/\-](19|20\d\d)");
            var phoneCheck = new Regex(@"\b([7-9])([0-9]{9})\b");
            var nameCheck = new Regex(@"\b[A-Za-z]{1,25}\b");

            List<DepartmentEntity> department = DatabaseOperation.DepartmentListDeSerializer();
            List<ProjectEntity> project = DatabaseOperation.ProjectListDeSerializer();
            List<RoleEntity> role = DatabaseOperation.RoleListDeSerializer();
            List<DepartmentEntity> checkDepartmentList = department.FindAll(val => val.employeeDepartmentId == (employee.employeeDepartmentId));
            List<ProjectEntity> checkProjectList = project.FindAll(val => val.projectId == (employee.employeeProjectId));
            List<RoleEntity> checkRoleList = role.FindAll(val => val.roleId == (employee.employeeRoleId));
            try
            {
                if (nameCheck.IsMatch(employee.employeeName))
                {
                    if (emailCheck.IsMatch(employee.employeeEmailId))
                    {
                        if (phoneCheck.IsMatch(employee.employeePhoneNumber.ToString()))
                        {
                            if (employee.employeeAddress.Length > 0)
                            {
                                if (dateCheck.IsMatch(employee.employeeDateOfBirth))
                                {
                                    if (dateCheck.IsMatch(employee.employeeDateOfJoining))
                                    {
                                        if (checkDepartmentList.Count > 0)
                                        {
                                            if (checkProjectList.Count > 0)
                                            {
                                                if (checkRoleList.Count > 0)
                                                {
                                                    return true;
                                                }
                                                else
                                                {
                                                    Console.WriteLine("Invalid Role Id refer Role table!!");
                                                    Console.ReadKey();
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("Invalid Project Id refer project table!!");
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid Department Id refer department table!!");
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Pleas enter proper date format as given!!");
                                        return false;
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Pleas enter proper date format as given!!");
                                    return false;
                                }
                            }
                            else
                            {
                                Console.WriteLine("Please first enter address!!");
                                return false;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid phone number format!!");
                            return false;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid email formate!!");
                        return false;
                    }

                }
                else
                {
                    Console.WriteLine("Name can't contain numbers or any special character!!");
                    return false;
                }
            }
            catch (EmployeeException employeeException)
            {
                Console.WriteLine(employeeException.Message);
                return false;
            }
            catch(Exception exception)
            {
                Console.WriteLine(exception.Message);
                return false;
            }

        }

        /*****************Validating data of department******************************/
        public static bool CheckDepartment(DepartmentEntity department)
        {
            if (department.departmentDescription.Length > 0 && department.departmentName.Length > 0)
                return true;
            else
                return false;
        }
        /*****************Validating data of Project******************************/
        public static bool CheckProject(ProjectEntity project)
        {
            List<DepartmentEntity> department = DatabaseOperation.DepartmentListDeSerializer();
            List<DepartmentEntity> checkDepartmentList = department.FindAll(val => val.employeeDepartmentId.Equals(project.employeeDepartmentId));

            if (project.projectName.Length > 0 && project.projectDescription.Length > 0 && checkDepartmentList.Count > 0)
                return true;
            else
                return false;
        }

        /*****************Validating data of Role******************************/
        public static bool CheckRole(RoleEntity role)
        {
            if (role.roleName.Length > 0 && role.roleDescription.Length > 0)
                return true;
            else
                return false;
        }

        /*****************Calling to checkEmployee than calling to dataaccess******************************/
        public static bool AddEmployee(EmployeeEntity employee)
        {


            if (CheckEmployee(employee))
            {
                DatabaseOperation.EmployeeListSerializer(employee);
                return true;
            }
            else
            {
                return false;
            }

        }
        /*****************Calling to checkDepartment than calling to dataaccess******************************/
        public static bool AddDepartment(DepartmentEntity department)
        {
            if (CheckDepartment(department))
            {
                DatabaseOperation.DepartmentListSerializer(department);
                return true;
            }
            else
            {
                return false;
            }

        }
        /*****************Calling to checkProject than calling to dataaccess******************************/
        public static bool AddProject(ProjectEntity project)
        {
            if (CheckProject(project))
            {
                DatabaseOperation.ProjectListSerializer(project);
                return true;
            }
            else
            {
                return false;
            }

        }
        /*****************Calling to checkRole than calling to dataaccess******************************/
        public static bool AddRole(RoleEntity role)
        {
            if (CheckRole(role))
            {
                DatabaseOperation.RoleListSerializer(role);
                return true;
            }
            else
            {
                return false;
            }

        }

        /****************Get all List of Employee*********************/
        public List<EmployeeEntity> GetAllEmployee()
        {
            return DatabaseOperation.EmployeeListDeSerializer();

        }

        /****************Get All List Of Department*********************/
        public List<DepartmentEntity> GetAllDepartment()
        {
            return DatabaseOperation.DepartmentListDeSerializer();

        }
        /****************Get All List Of Projects*********************/
        public List<ProjectEntity> GetAllProject()
        {
            return DatabaseOperation.ProjectListDeSerializer();

        }
        /****************Get All List Of Roles*********************/
        public List<RoleEntity> GetAllRole()
        {
            return DatabaseOperation.RoleListDeSerializer();

        }

        /********************* Search employee **********************************/
        public List<EmployeeEntity> SearchEmployee(string search)
        {

            List<EmployeeEntity> employee = DatabaseOperation.EmployeeListDeSerializer();
            List<EmployeeEntity> employeeSearched = employee.FindAll(val => val.employeeKinId.Equals(search) || val.employeeName.Equals(search) || val.employeeEmailId.Equals(search));

            return employeeSearched;
        }
        /********************* calling to the remove method of dataaccess layer*****************/
        public bool RemoveEmployee(string removeItem)
        {
            if (DatabaseOperation.RemoveEmployeeDal(removeItem))
                return true;
            else
                return false;

        }
        public bool ModifyEmployee(string modifyItem)
        {
            if (DatabaseOperation.ModifyEmployeeDal(modifyItem))
                return true;
            else
                return false;
        }
        }

    }