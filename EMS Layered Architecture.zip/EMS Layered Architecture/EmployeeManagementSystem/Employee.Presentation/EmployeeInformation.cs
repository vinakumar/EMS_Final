﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.Entity;
using Employee.BusinessLogic;
using Employee.Exceptions;
namespace Employee.Presentation
{
    class EmployeeInformation
    {
        public static EmployeeLogic employeeLogic = new EmployeeLogic();
        public static List<EmployeeEntity> EmployeeList = new List<EmployeeEntity>();
        static void Main(string[] args)
        {
            int choice;

            while (true)
            {
                Console.WriteLine("Enter your Choice");
                Console.WriteLine("1. Add:");
                Console.WriteLine("2. Display:");
                Console.WriteLine("3. Search Employee:");
                Console.WriteLine("4. Remove Employee:");
                Console.WriteLine("5. Modify Employee Details:");
                Console.WriteLine("6. Exit");
                try {
                    choice = Convert.ToInt32(Console.ReadLine());
                    Console.Clear();
                    //menu driven in which you do the operation
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter your Choice!!");

                            Console.WriteLine("1. Add Department Details:");
                            Console.WriteLine("2. Add Project Details:");
                            Console.WriteLine("3. Add Role Details:");
                            Console.WriteLine("4. Add Employee Details:");
                            Console.WriteLine("5. Exit");
                            int inputIn = Convert.ToInt32(Console.ReadLine());
                            switch (inputIn)
                            {

                                case 1:
                                    if (EmployeeLogic.AddDepartment(GetDepartmentData()))
                                        Console.WriteLine("Department information is added Successfully");
                                    else
                                        Console.WriteLine("Error in adding Department information!!!");
                                    break;

                                case 2:
                                    if (EmployeeLogic.AddProject(GetProjectData()))
                                        Console.WriteLine("Project information is added Successfully");
                                    else
                                        Console.WriteLine("Error in adding Project information!!!");
                                    break;

                                case 3:
                                    if (EmployeeLogic.AddRole(GetRoleData()))
                                        Console.WriteLine("Role information is added Successfully");
                                    else
                                        Console.WriteLine("Error in adding Role information!!!");
                                    break;

                                case 4:
                                    if (EmployeeLogic.AddEmployee(GetEmployeeData()))
                                        Console.WriteLine("Employee information is added Successfully");
                                    else
                                        Console.WriteLine("Error in adding Employee information!!!");
                                    break;

                                case 5:
                                    Environment.Exit(0);
                                    break;
                                default:
                                    Console.WriteLine("Enter the valid input!!!");
                                    break;
                            }
                            break;

                        case 2:
                            Console.WriteLine("Enter your Choice!!");
                            Console.WriteLine("1. Display Department Details:");
                            Console.WriteLine("2. Display Project Details:");
                            Console.WriteLine("3. Display Role Details:");
                            Console.WriteLine("4. Display Employee Details:");
                            Console.WriteLine("5. Exit");
                            int inputOut = Convert.ToInt32(Console.ReadLine());
                            switch (inputOut)
                            {

                                case 1:
                                    DisplayDepartment(employeeLogic.GetAllDepartment());
                                    break;

                                case 2:
                                    DisplayProject(employeeLogic.GetAllProject());
                                    break;

                                case 3:
                                    DisplayRole(employeeLogic.GetAllRole());
                                    break;

                                case 4:
                                    DisplayEmployee(employeeLogic.GetAllEmployee());
                                    break;

                                case 5:
                                    Environment.Exit(0);
                                    break;
                                default:
                                    Console.WriteLine("Enter the valid input!!!");
                                    break;
                            }
                            break;

                        case 3:
                            Console.WriteLine("Enter the employee KinId OR Name OR EmailId you want to search:");
                            string search = Console.ReadLine();
                            List<EmployeeEntity> searchedEmployee = employeeLogic.SearchEmployee(search);
                            if (searchedEmployee.Count > 0)
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("---------------------------------------------Searched Employee---------------------------------------------------------");
                                Console.WriteLine("Name" + "  " + "Id" + "   " + "KinId" + "  " + "EmailId" + "  " + "Ph.Number" + "  " + "Address" + "  " + "DateOfBirth" + "  " + "DateOfJoining"
                                    + "  " + "DepartmentID" + "  " + "ProjectID" + "  " + "RoleID");
                                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                                Console.ForegroundColor = ConsoleColor.White;
                                foreach (EmployeeEntity employee in searchedEmployee)
                                {
                                    Console.WriteLine($"{employee.employeeName}  {employee.employeeId}  {employee.employeeKinId}  {employee.employeeEmailId}   {employee.employeePhoneNumber}" +
                                        $" {employee.employeeAddress}  {employee.employeeDateOfBirth}  {employee.employeeDateOfJoining} " +
                                        $"   {employee.employeeDepartmentId}  {employee.employeeProjectId}  {employee.employeeRoleId}");
                                }
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.ReadKey();
                                Console.Clear();
                            }
                            else
                            {
                                Console.WriteLine($"Employee with the specified KinId or Name or EmailId: {search} does not present!");
                            }

                            break;
                        case 4:
                            DisplayEmployee(employeeLogic.GetAllEmployee()); //for displaying whole list
                            Console.WriteLine("Choose the KinId Or EmployeeId From Above List for removing employee!!:");
                            string removeItem = Console.ReadLine();
                            bool removeStatus = employeeLogic.RemoveEmployee(removeItem);
                            if (removeStatus == true)
                            {
                                Console.WriteLine("Employee successfully removed!!");
                                DisplayEmployee(employeeLogic.GetAllEmployee());
                            }

                            else
                                Console.WriteLine($"Employee with Id: {removeItem}: does not exist!!");

                            break;
                        case 5:

                            DisplayEmployee(employeeLogic.GetAllEmployee()); //for displaying whole list
                            Console.WriteLine("Enter the KinId Or EmployeeId From Above List for Modify employee!!:");
                            string modifyItem = Console.ReadLine();
                            bool modifyStatus = employeeLogic.ModifyEmployee(modifyItem);
                            if (modifyStatus == true)
                            {
                                Console.WriteLine("Employee Modify successfully!!");
                                DisplayEmployee(employeeLogic.GetAllEmployee());
                            }

                            else
                                Console.WriteLine($"Error in modifying employee with Id: {modifyItem}: !!");
                            break;
                        case 6:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }catch(FormatException formateException)
                {
                    Console.WriteLine("Invalid Format of data!!");
                }
                catch(Exception exception)
                {
                    Console.WriteLine(exception.Message);
                }
           }
        }

        /*****************Enter employee details******************************/
        public static EmployeeEntity GetEmployeeData()
        {

            EmployeeEntity employee = new EmployeeEntity();
            List<DepartmentEntity> department = employeeLogic.GetAllDepartment();
            List<ProjectEntity> project = employeeLogic.GetAllProject();
            List<RoleEntity> role = employeeLogic.GetAllRole();
            Console.WriteLine("Enter Name:");
            employee.employeeName = Console.ReadLine();
            Console.WriteLine("Enter EmailId:");
            employee.employeeEmailId = Console.ReadLine();
            Console.WriteLine("Enter 10 Digit PhoneNumber:");
            employee.employeePhoneNumber = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter Address:");
            employee.employeeAddress = Console.ReadLine();
            Console.WriteLine("Enter DateOfBirth: [dd/mm/yyyy] Or [dd-mm-yyyyy] Or [dd.mm.yyyy]");
            employee.employeeDateOfBirth = Console.ReadLine();
            Console.WriteLine("Enter DateOfJoining: [dd/mm/yyyy] Or [dd-mm-yyyyy] Or [dd.mm.yyyy]");
            employee.employeeDateOfJoining = Console.ReadLine();
            Console.WriteLine("Choose Department ID from The below List:");
            foreach (DepartmentEntity dpt in department)
            {
                Console.WriteLine($"{dpt.employeeDepartmentId}: {dpt.departmentName}");
            }
            employee.employeeDepartmentId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Project ID from The following List:");
            foreach (ProjectEntity pro in project)
            {
                Console.WriteLine($"{pro.projectId}: {pro.projectName}");
            }
            employee.employeeProjectId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Choose Role ID from The below List:");
            foreach (RoleEntity rol in role)
            {
                Console.WriteLine($"{rol.roleId}: {rol.roleName}");
            }
            employee.employeeRoleId = Convert.ToInt32(Console.ReadLine());
            return employee;
        }
        /*****************Enter Department details******************************/
        public static DepartmentEntity GetDepartmentData()
        {
            DepartmentEntity department = new DepartmentEntity();
            Console.WriteLine("Enter Department Name:");
            department.departmentName = Console.ReadLine();
            Console.WriteLine("Enter Department Description:");
            department.departmentDescription = Console.ReadLine();
            return department;
        }
        /*****************Enter Project details******************************/
        public static ProjectEntity GetProjectData()
        {
            ProjectEntity project = new ProjectEntity();
            Console.WriteLine("Enter Project Name:");
            project.projectName = Console.ReadLine();
            Console.WriteLine("Enter Project Description:");
            project.projectDescription = Console.ReadLine();
            Console.WriteLine("Enter Department Id:");
            project.employeeDepartmentId = Convert.ToInt32(Console.ReadLine());
            return project;
        }
        /*****************Enter employee details******************************/
        public static RoleEntity GetRoleData()
        {
            RoleEntity role = new RoleEntity();
            Console.WriteLine("Enter Role Name:");
            role.roleName = Console.ReadLine();
            Console.WriteLine("Enter Role description:");
            role.roleDescription = Console.ReadLine();
            return role;
        }


        /***************** Displaying all record of employees ******************************/
        public static void DisplayEmployee(List<EmployeeEntity> employees)
        {
            Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine("--------------------------------------------------Employees List--------------------------------------------------------");
            Console.WriteLine("Name" + "  " + "Id" + "   " + "KinId" + "  " + "EmailId" + "  " + "Ph.Number" + "  " + "Address" + "  " + "DateOfBirth" + "  " + "DateOfJoining"
                + "  " + "DepartmentID" + "  " + "ProjectID" + "  " + "RoleID");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            foreach (EmployeeEntity employee in employees)
            {
                Console.WriteLine($"{employee.employeeName}  {employee.employeeId}  {employee.employeeKinId}  {employee.employeeEmailId}   {employee.employeePhoneNumber}" +
                    $" {employee.employeeAddress}  {employee.employeeDateOfBirth}  {employee.employeeDateOfJoining} " +
                    $"   {employee.employeeDepartmentId}  {employee.employeeProjectId}  {employee.employeeRoleId}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }
        /***************** Displaying all record of Department ******************************/
        public static void DisplayDepartment(List<DepartmentEntity> departments)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("-----------------------------Department Record-----------------------");
            Console.WriteLine("Name" + "  " + "Id" + "  " + "Description");
            Console.WriteLine("----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            foreach (DepartmentEntity department in departments)
            {
                Console.WriteLine($"{department.departmentName}  {department.employeeDepartmentId}  {department.departmentDescription}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }
        /***************** Displaying all record of Projects ******************************/
        public static void DisplayProject(List<ProjectEntity> projects)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("-----------------------------Project Record---------------------------");
            Console.WriteLine("Name" + "  " + "ProjectId" + "  " + "Description" + "  " + "DepartmentId");
            Console.WriteLine("-----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            foreach (ProjectEntity project in projects)
            {
                Console.WriteLine($"{project.projectName}  {project.projectId}  {project.projectDescription}  {project.employeeDepartmentId}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("-----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }
        /***************** Displaying all record of Roles ******************************/
        public static void DisplayRole(List<RoleEntity> roles)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("-------------------------------Role Record---------------------------");
            Console.WriteLine("Name" + "  " + "RoleId" + "  " + "Description");
            Console.WriteLine("----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            foreach (RoleEntity role in roles)
            {
                Console.WriteLine($"{role.roleName}  {role.roleId}  {role.roleDescription}");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }

    }
}
