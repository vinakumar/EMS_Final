﻿using System;
using Employee.Entity;
using Employee.Exceptions;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;
namespace Employee.DataAccess
{
    public class DatabaseOperation
    {
        public static List<EmployeeEntity> employees = new List<EmployeeEntity>();
        public static List<DepartmentEntity> departments = new List<DepartmentEntity>();
        public static List<ProjectEntity> projects = new List<ProjectEntity>();
        public static List<RoleEntity> roles = new List<RoleEntity>();
        /************************************** Seralizing Employee Data **************************************************/
        public static void EmployeeListSerializer(EmployeeEntity employee)
        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Employees.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {


                if (File.Exists(path))
                {
                    int MaxEmployeeId = 0;

                    employees = EmployeeListDeSerializer();
                    if (employees.Count > 0)
                    {

                        foreach (EmployeeEntity emp in employees)
                        {
                            if (emp.employeeId > MaxEmployeeId)
                                MaxEmployeeId = emp.employeeId;
                        }
                        employee.employeeId = MaxEmployeeId + 1;
                        employee.employeeKinId = "KIN" + MaxEmployeeId + 1;
                        employees.Add(employee);
                        Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                        formatter.Serialize(stream, employees);
                        stream.Close();
                    }

                }
                else
                {
                    employee.employeeId = 1;  //Initial id of Employee
                    employee.employeeKinId = "KIN" + 1;
                    employees.Add(employee);

                    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                    formatter.Serialize(stream, employees);
                    stream.Close();
                }
            }
            catch (FileNotFoundException fileException)
            {
                Console.WriteLine("File Not Exixt In Current Context!!:");
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
            }

        }

        /************************************** Seralizing Department Data **************************************************/
        public static void DepartmentListSerializer(DepartmentEntity department)
        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Departments.txt";

            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                if (File.Exists(path))
                {
                    int MaxDepartmentId = 100;

                    departments = DepartmentListDeSerializer();
                    if (departments.Count > 0)
                    {
                        foreach (DepartmentEntity dpt in departments)
                        {
                            if (dpt.employeeDepartmentId > MaxDepartmentId)
                                MaxDepartmentId = dpt.employeeDepartmentId;
                        }
                        department.employeeDepartmentId = MaxDepartmentId + 1;

                        departments.Add(department);
                        Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                        formatter.Serialize(stream, departments);
                        stream.Close();
                    }

                }
                else
                {
                    department.employeeDepartmentId = 100;  //Initial id of Department
                    departments.Add(department);
                    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                    formatter.Serialize(stream, departments);
                    stream.Close();
                }
            }
            catch (FileNotFoundException fileException)
            {
                Console.WriteLine("File Not Exixt In Current Context!!:");
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
            }

        }

        /************************************** Seralizing Project Data **************************************************/
        public static void ProjectListSerializer(ProjectEntity project)
        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Projects.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                if (File.Exists(path))
                {
                    int MaxProjectId = 1000;
                    projects = ProjectListDeSerializer();
                    if (projects.Count > 0)
                    {
                        foreach (ProjectEntity pro in projects)
                        {
                            if (pro.projectId > MaxProjectId)
                                MaxProjectId = pro.projectId;
                        }
                        project.projectId = MaxProjectId + 1;
                        projects.Add(project);
                        Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                        formatter.Serialize(stream, projects);
                        stream.Close();
                    }
                }
                else
                {
                    project.projectId = 1000;  //Initial id of Project
                    projects.Add(project);
                    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                    formatter.Serialize(stream, projects);
                    stream.Close();
                }
            }
            catch (FileNotFoundException fileException)
            {
                Console.WriteLine("File Not Exixt In Current Context!!:");
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
            }

        }

        /************************************** Seralizing Role Data **************************************************/
        public static void RoleListSerializer(RoleEntity role)
        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Roles.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                if (File.Exists(path))
                {
                    int MaxRoleId = 2000;
                    roles = RoleListDeSerializer();
                    if (roles.Count > 0)
                    {
                        foreach (RoleEntity rol in roles)
                        {
                            if (rol.roleId > MaxRoleId)
                                MaxRoleId = rol.roleId;
                        }
                        role.roleId = MaxRoleId + 1;
                        roles.Add(role);
                        Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                        formatter.Serialize(stream, roles);
                        stream.Close();
                    }
                }
                else
                {
                    role.roleId = 2000;  //Initial id of Role
                    roles.Add(role);
                    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                    formatter.Serialize(stream, roles);
                    stream.Close();
                }
            }
            catch (FileNotFoundException fileException)
            {
                Console.WriteLine("File Not Exixt In Current Context!!:");
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
            }

        }

        /******************************* Desirializing Employee Data*******************************************/
        public static List<EmployeeEntity> EmployeeListDeSerializer()

        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Employees.txt";
            BinaryFormatter formatter = new BinaryFormatter();

            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<EmployeeEntity> employee = (List<EmployeeEntity>)formatter.Deserialize(stream);
            stream.Close();
            return employee;
        }

        /******************************* Desirializing Department Data*******************************************/
        public static List<DepartmentEntity> DepartmentListDeSerializer()

        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Departments.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<DepartmentEntity> department = (List<DepartmentEntity>)formatter.Deserialize(stream);
            stream.Close();
            return department;
        }
        /******************************* Desirializing  Project Data*******************************************/
        public static List<ProjectEntity> ProjectListDeSerializer()

        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Projects.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<ProjectEntity> project = (List<ProjectEntity>)formatter.Deserialize(stream);
            stream.Close();
            return project;
        }
        /******************************* Desirializing  Role Data*******************************************/
        public static List<RoleEntity> RoleListDeSerializer()

        {
            string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Roles.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<RoleEntity> role = (List<RoleEntity>)formatter.Deserialize(stream);
            stream.Close();
            return role;
        }

        /*************************** For Remove operation on the list*******************************/
        public static bool RemoveEmployeeDal(string removeItem)
        {
            List<EmployeeEntity> updatedEmployee = EmployeeListDeSerializer();
            try
            {
                EmployeeEntity employeeSearched = updatedEmployee.Find(val => val.employeeKinId.Equals(removeItem) || val.employeeId == Convert.ToInt32(removeItem));
                if (employeeSearched != null)
                {
                    updatedEmployee.Remove(employeeSearched);
                    string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Employees.txt";
                    BinaryFormatter formatter = new BinaryFormatter();
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, updatedEmployee);
                    stream.Close();
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch(NullReferenceException fileException)
            {
                Console.WriteLine("Object does not contain any value!!");
                return false;
            }
            catch (FileNotFoundException fileException)
            {
                Console.WriteLine("File Not Exixt In Current Context!!:");
                return false;
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
                return false;
            }

        }
        /*************************** For modification operation on perticular employee*******************************/
        public static bool ModifyEmployeeDal(string modifyItem)
        {
            /****************************************************************************************************/
            var emailCheck = new Regex(@"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com\b");
            var dateCheck = new Regex(@"(0[1-9]|[12][0-9]|3[01])[- \.\/\-](0[1-9]|1[012])[- \.\/\-](19|20\d\d)");
            var phoneCheck = new Regex(@"\b([7-9])([0-9]{9})\b");
            var nameCheck = new Regex(@"\b[A-Za-z]{1,25}\b");

            List<DepartmentEntity> department = DepartmentListDeSerializer();
            List<ProjectEntity> project = ProjectListDeSerializer();
            List<RoleEntity> role = RoleListDeSerializer();
            List<EmployeeEntity> modifyEmployee = EmployeeListDeSerializer();
            EmployeeEntity employeeSearched = modifyEmployee.Find(val => val.employeeKinId.Equals(modifyItem) || val.employeeId == Convert.ToInt32(modifyItem));
            if (employeeSearched != null)
            {
                int index = modifyEmployee.IndexOf(employeeSearched);
                Console.WriteLine("What you want to modify Press!! \n");
                Console.WriteLine("1. Name:");
                Console.WriteLine("2. EmailId:");
                Console.WriteLine("3. Phone Number:");
                Console.WriteLine("4. Date Of Birth:");
                Console.WriteLine("5. Date Of Joining:");
                Console.WriteLine("6. Address:");
                Console.WriteLine("7. Dpartment Id:");
                Console.WriteLine("8. Project Id:");
                Console.WriteLine("9. Role Id:");
                try
                {
                    int input = Convert.ToInt32(Console.ReadLine());
                    switch (input)
                    {

                        case 1:
                            Console.WriteLine("Enter the new name:");

                            employeeSearched.employeeName = Console.ReadLine();
                            if (nameCheck.IsMatch(employeeSearched.employeeName))
                            {

                            }
                            else
                            {
                                Console.Write("Name can't contain numbers or any special character!!");
                                return false;
                            }
                            break;

                        case 2:
                            Console.WriteLine("Enter the new Email Id:");
                            employeeSearched.employeeEmailId = Console.ReadLine();
                            if (nameCheck.IsMatch(employeeSearched.employeeEmailId))
                            {

                            }
                            else
                            {
                                Console.Write("Invalid email formate!!");
                                return false;
                            }
                            break;
                        case 3:
                            Console.WriteLine("Enter the new phone number:");
                            employeeSearched.employeePhoneNumber = Convert.ToInt64(Console.ReadLine());
                            if (nameCheck.IsMatch(employeeSearched.employeePhoneNumber.ToString()))
                            {

                            }
                            else
                            {
                                Console.Write("Invalid mobile formate!!");
                                return false;
                            }

                            break;
                        case 4:
                            Console.WriteLine("Enter the new Date Of Birth:");
                            employeeSearched.employeeDateOfBirth = Console.ReadLine();
                            if (nameCheck.IsMatch(employeeSearched.employeeDateOfBirth))
                            {

                            }
                            else
                            {
                                Console.Write("Invalid Date formate!!");
                                return false;
                            }
                            break;
                        case 5:
                            Console.WriteLine("Enter the new Date Of Joining:");
                            employeeSearched.employeeDateOfJoining = Console.ReadLine();
                            if (nameCheck.IsMatch(employeeSearched.employeeDateOfJoining))
                            {

                            }
                            else
                            {
                                Console.Write("Invalid Date formate!!");
                                return false;
                            }
                            break;
                        case 6:
                            Console.WriteLine("Enter the new Address:");
                            employeeSearched.employeeAddress = Console.ReadLine();
                            if (employeeSearched.employeeDateOfBirth.Length > 0)
                            {

                            }
                            else
                            {
                                Console.Write("Enter the address!!");
                                return false;
                            }
                            break;
                        case 7:
                            Console.WriteLine("Enter the new Department Id:");
                            employeeSearched.employeeDepartmentId = Convert.ToInt32(Console.ReadLine());
                            List<DepartmentEntity> checkDepartmentList = department.FindAll(val => val.employeeDepartmentId == (employeeSearched.employeeDepartmentId));
                            if (checkDepartmentList.Count > 0)
                            {

                            }
                            else
                            {
                                Console.WriteLine("Invalid Department Id refer department table!!");
                                return false;

                            }
                            break;
                        case 8:
                            Console.WriteLine("Enter the new Project Id:");
                            employeeSearched.employeeProjectId = Convert.ToInt32(Console.ReadLine());
                            List<ProjectEntity> checkProjectList = project.FindAll(val => val.projectId == (employeeSearched.employeeProjectId));
                            if (checkProjectList.Count > 0)
                            {

                            }
                            else
                            {
                                Console.WriteLine("Invalid Project Id refer project table!!");
                                return false;
                            }
                            break;
                        case 9:
                            Console.WriteLine("Enter the new Role Id:");
                            employeeSearched.employeeRoleId = Convert.ToInt32(Console.ReadLine());
                            List<RoleEntity> checkRoleList = role.FindAll(val => val.roleId == (employeeSearched.employeeRoleId));
                            if (checkRoleList.Count > 0)
                            {

                            }
                            else
                            {
                                Console.WriteLine("Invalid Role Id refer Role table!!");
                                return false;
                            }
                            break;
                        default:
                            Console.WriteLine("Choose the valid field!!!");
                            break;
                    }
                }
                catch (FormatException format) {
                    Console.WriteLine("Formate of data is not correct!!");
                }
                catch(Exception exception)
                {
                    Console.WriteLine(exception.Message);
                }

                modifyEmployee.RemoveAt(index);
                modifyEmployee.Insert(index, employeeSearched);
                Console.ReadKey();

                string path = @"C:\Users\hp\Desktop\EMS Layered Architecture\EmployeeManagementSystem\DataBase\Employees.txt";
                BinaryFormatter formatter = new BinaryFormatter();
                Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                formatter.Serialize(stream, modifyEmployee);
                stream.Close();
                return true;
            }
            else
                return false;
        }
    }
}
